<?php
session_start();
include_once('../Database/DBMySql.php');$db=new DBMySql;
$PostData =json_decode(file_get_contents("php://input"));

$flag=true;
$UID=1;if(isset($_SESSION['UID'])) $UID=$_SESSION['UID'];
$uname=$_SESSION['UserName'];


//$UID=$_SESSION["UID"];
$BillAmount=$PostData->BillAmount;
//$ShopId = $PostData[0]->UID;
$con=$db->GetActiveConnection();
$OrderNumber =100001 ;
if($db->ScalerQueryOnConnection("select COUNT(*) from ordersbycustomers",$con)>0)$OrderNumber=$db->ScalerQueryOnConnection("SELECT MAX(OrderNumber)+1 FROM ordersbycustomer",$con);
foreach($PostData->Products as $order)
{
    $db->NonQueryOnConnection("INSERT INTO `orderinfo`(`ProductID`,`Quantity`,`Price`,`OrderNumber`,`TotalPrice`,`ProdName`) VALUES(".$order->PID.",".$order->Quantity.",".$order->Price.",".$OrderNumber.",".($order->Quantity*$order->Price).",'$order->ProductName')",$con);
}

$sqql="SELECT Email,Mobile,Address FROM customers WHERE UID = $UID;";

if ($result = mysqli_query($con, $sqql)) {
    while($row = $result->fetch_assoc())
    {
        $em = $row['Email'];
        $mob=$row['Mobile'];
        $add=$row['Address'];
    }
}


$sql = "INSERT INTO `ordersbycustomer`(`OrderNumber`,`OrderDate`,`BillAmount`,`UID`,`CustomerName`,`CustomerEmail`,`CustomerMobile`,`CustomerAddress`) VALUES (".$OrderNumber.",NOW(),".$BillAmount.",".$UID.",'$uname','$em','$mob','$add');";


if($db->NonQueryOnConnection($sql,$con))
{
    $Response["Status"]='Success';
    $Response["Message"]="Order Placed Successfully";
}
else{
    $Response["Status"]='Error';
    $Response["Message"]=$sql;
}
$con->close();
echo json_encode($Response);

?>